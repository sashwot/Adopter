using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerI : MonoBehaviour
{
    
    [SerializeField] float moveSpeed = 0.01f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {    // model: playerI is the object that this class is assigned to. 
        //control: moveammount controls the ammount of y axis of the player.
        
        float moveAmount = Input.GetAxis("Vertical") * moveSpeed;
        
        transform.Translate(0,moveAmount,0);
    }
}
