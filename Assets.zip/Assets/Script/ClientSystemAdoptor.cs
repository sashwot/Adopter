using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
//So class ClientSystemAdoptor acts as an adoptor class between InventoryItem class and InventoryAsset interface
public class ClientSystemAdoptor : InventoryItem , InventoryAsset
{
    private List<SaveLocation> Drive = new List<SaveLocation>();
    public void DisplayItem(InventoryItem anItem, SaveLocation aLocation)
    {
        if(anItem != null && aLocation == SaveLocation.Cloud)
        {
            DisplayItem(anItem);
        }
        

    }

    public void DisplayLocation(SaveLocation aLocation, InventoryItem anItem)
    {
        if (anItem != null && aLocation == SaveLocation.Cloud)
        {
            DisplayLocation(aLocation);
        }
    }

    public List<SaveLocation> Locations(SaveLocation aLocation, InventoryItem anItem)
    {
        this.Drive.Add(aLocation);

        return this.Drive;
    }


}
