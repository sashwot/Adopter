using System.Collections;
using System.IO;
using System;
using System.Collections.Generic;
using UnityEngine;

// InventoryItem class Displays Item and location in .txt file on the given path.
// InventoryItem and InventoryAssets will be implemented by ClientSystemAdoptor 
public class InventoryItem
{
    // place holder class you will need to flesh this out for your assignment
    // you can change it to a monster or npc or any thing
    public void DisplayItem(InventoryItem anItem)
    {
        Console.WriteLine("Starting file access");
        var path = "/Users/sashwotkoirala/Desktop/test.txt";
        StreamReader reader = new StreamReader(path);
        var input = reader.ReadToEnd();
        reader.Close();
        //Console.WriteLine();
        StreamWriter writer = new StreamWriter(path);
        InventoryItem output = anItem;
        writer.Write (output);
        writer.Close();
    }

    public void DisplayLocation(SaveLocation aLocation)
    {
        Console.WriteLine("Starting file access");
        var path = "/Users/sashwotkoirala/Desktop/test.txt";
        StreamReader reader = new StreamReader(path);
        var input = reader.ReadToEnd();
        reader.Close();
        StreamWriter writer = new StreamWriter(path);
        SaveLocation output = aLocation;
        writer.Write(output);
        writer.Close();

    }

    public List<SaveLocation> Locations(SaveLocation aLocation)
    {
        return new List<SaveLocation>();
    }


}
