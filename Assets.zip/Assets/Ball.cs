using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        rb.AddForce(new Vector3(1f,1f,1f),ForceMode2D.Impulse);
    }

    public Rigidbody2D rb;
   

    // Update is called once per frame
    void Update()
    {
        
    }
}
