using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClientAdopter : MonoBehaviour
{
    private InventoryItem item;
    private InventoryAsset asset;

    private InventorySystem inventorySystem;
    private IInventorySystem InventorySystemAdopter;

    private void Start()
    {
        inventorySystem = new InventorySystem();
        InventorySystemAdopter = new InventorySystemAdopter();

    }

    private void OnGUI()
    {
        if (GUILayout.Button("Add item (no adopter)"))
        {
            inventorySystem.AddItem(item);
        }

        if (GUILayout.Button("Add item (with adoptor"))
        {
            InventorySystemAdopter.AddItem(item, SaveLocation.Both);
        }
    }
}
