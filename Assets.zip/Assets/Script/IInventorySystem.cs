using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// This 
public interface IInventorySystem 
{
    void SyncInventories();

    void AddItem(InventoryItem anItem, SaveLocation aLocation);

    void Removeitem(InventoryItem anItem, SaveLocation aLocation);

    List<InventoryItem> GetInventory(SaveLocation aLocation);
}
