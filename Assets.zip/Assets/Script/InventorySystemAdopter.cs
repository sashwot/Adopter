using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventorySystemAdopter : InventorySystem, IInventorySystem
{
    private List<InventoryItem> cloudInventory;
    //private List<SaveLocation> locality;
    
    public void SyncInventories()
    {
        var cloudInventory = GetInventory();
        Debug.Log("Downloading the cloud inventory");
    }

    public void AddItem(InventoryItem anItem, SaveLocation aLocation)
    {
        if(aLocation == SaveLocation.Cloud)
        {
            AddItem(anItem);
        }

        if (aLocation == SaveLocation.Local)
        {
            AddItem(anItem);
            Debug.Log("We need code here to save to local drive");
        }
    }

    public void Removeitem(InventoryItem anItem, SaveLocation aLocation)
    {
        if(aLocation == SaveLocation.Cloud)
        {
            RemoveItem(anItem);
            Debug.Log("We need code here to save to local drive");
        }

        if(aLocation == SaveLocation.Both)
        {
            RemoveItem(anItem);
            Debug.Log("We need code here to save to local drive");
        }
    }

    public List<InventoryItem> GetInventory(SaveLocation aLocation)
    {
        if (aLocation == SaveLocation.Cloud)
        {
            GetInventory();
        }

        if (aLocation == SaveLocation.Local)
        {
            Debug.Log("We need code here to get the Inventory from the Local drive");
        }

        if (aLocation == SaveLocation.Both)
        {
            GetInventory();
            
        }

        return new List<InventoryItem>();
    }

}
