using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface InventoryAsset
{
    public void DisplayItem(InventoryItem anItem, SaveLocation aLocation);

    public void DisplayLocation(SaveLocation aLocation, InventoryItem anItem);

    public List<SaveLocation> Locations(SaveLocation aLocation, InventoryItem anItem);
 
}
